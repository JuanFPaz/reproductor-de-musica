This template / effect / code has been created by Roemerdt.
You can customize and check it out on its original site on the following link:
https://codepen.io/Roemerdt/pen/rOqVZx

Thank you